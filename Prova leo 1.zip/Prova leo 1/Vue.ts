import Vue from 'vue';

interface Calculator {
  display: string;// Importação do Vue.js para uso no projeto
  import Vue from 'vue';
  
  // Definição de uma interface para descrever a estrutura da calculadora
  interface Calculator {
    display: string; // O display da calculadora
    numbers: Array<number>; // Os números disponíveis para entrada
    operator: string; // O operador atualmente selecionado (+, -, *, /)
    firstNum: string; // O primeiro número na operação
    secondNum: string; // O segundo número na operação
  }
  
  // Instância do Vue com definição dos dados e métodos da calculadora
  const app = new Vue({
    el: '#app', // Elemento HTML onde o Vue será montado
    data: {
      display: '0', // Inicializa o display com zero
      numbers: [1, 2, 3, 4, 5, 6, 7, 8, 9, 0], // Números disponíveis
      operator: '', // Operador selecionado
      firstNum: '', // Primeiro número na operação
      secondNum: '', // Segundo número na operação
    },
    methods: {
      // Adiciona um número ao display da calculadora
      addToDisplay(num: number | string) {
        // Verifica se num é um número e converte para string, se necessário
        if (typeof num === 'number') {
          num = num.toString();
        }
        // Atualiza o display com o número adicionado
        if (this.display === '0' || this.operator !== '') {
          this.display = num.toString();
        } else {
          this.display += num.toString();
        }
      },
      // Seleciona um operador para a operação
      operation(op: string) {
        // Define o operador selecionado e atualiza o primeiro número
        this.operator = op;
        this.firstNum = parseFloat(this.display).toString();
        this.display = '0'; // Reinicia o display para o próximo número
      },
      // Calcula o resultado da operação
      calculate() {
        // Atualiza o segundo número com o valor do display
        this.secondNum = parseFloat(this.display).toString();
        let result: number | string = ''; // Variável para armazenar o resultado
        // Executa a operação com base no operador selecionado
        switch (this.operator) {
          case '+':
            result = (parseFloat(this.firstNum) + parseFloat(this.secondNum)).toString();
            break;
          case '-':
            result = (parseFloat(this.firstNum) - parseFloat(this.secondNum)).toString();
            break;
          case '*':
            result = (parseFloat(this.firstNum) * parseFloat(this.secondNum)).toString();
            break;
          case '/':
            result = (parseFloat(this.firstNum) / parseFloat(this.secondNum)).toString();
            break;
          default:
            result = ''; // Caso de erro ou nenhum operador selecionado
        }
        this.display = result; // Atualiza o display com o resultado da operação
      },
      // Limpa o display e reseta a calculadora
      clear() {
        this.display = '0'; // Limpa o display
        this.operator = ''; // Reseta o operador
        this.firstNum = ''; // Reseta o primeiro número
        this.secondNum = ''; // Reseta o segundo número
      },
    },
  });
  
  export default app; // Exporta a instância do Vue para uso em outros arquivos, se necessário
  
  numbers: Array<number>;
  operator: string;
  firstNum: string;
  secondNum: string;
}

const app = new Vue({
  el: '#app',
  data: {
    display: '0',
    numbers: [1, 2, 3, 4, 5, 6, 7, 8, 9, 0],
    operator: '',
    firstNum: '',
    secondNum: '',
  },
  methods: {
    addToDisplay(num: number | string) {
      if (typeof num === 'number') {
        num = num.toString();
      }
      if (this.display === '0' || this.operator !== '') {
        this.display = num.toString();
      } else {
        this.display += num.toString();
      }
    },
    operation(op: string) {
      this.operator = op;
      this.firstNum = parseFloat(this.display).toString();
      this.display = '0';
    },
    calculate() {
      this.secondNum = parseFloat(this.display).toString();
      let result: number | string = '';
      switch (this.operator) {
        case '+':
          result = (parseFloat(this.firstNum) + parseFloat(this.secondNum)).toString();
          break;
        case '-':
          result = (parseFloat(this.firstNum) - parseFloat(this.secondNum)).toString();
          break;
        case '*':
          result = (parseFloat(this.firstNum) * parseFloat(this.secondNum)).toString();
          break;
        case '/':
          result = (parseFloat(this.firstNum) / parseFloat(this.secondNum)).toString();
          break;
        default:
          result = '';
      }
      this.display = result;
    },
    clear() {
      this.display = '0';
      this.operator = '';
      this.firstNum = '';
      this.secondNum = '';
    },
  },
});

export default app;

